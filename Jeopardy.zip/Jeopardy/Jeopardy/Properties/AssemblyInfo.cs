﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Jeopardy")]
[assembly: AssemblyDescription("Welcome to Jeopardy! This program will allow you to import a list of categories and questions" +
                                "and play Jeopardy with two teams!")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("USMC & USAF 2020")]
[assembly: AssemblyProduct("Jeopardy")]
[assembly: AssemblyCopyright("Copyright © USMC / USAF 2020")]
[assembly: AssemblyTrademark("None")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("33223f42-403a-4f46-82c8-76156fe370e8")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
